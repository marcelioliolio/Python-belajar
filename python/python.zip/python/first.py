
print("hello world")

str="*"
for i in range(5):
    print(str)
    str+="*"  
